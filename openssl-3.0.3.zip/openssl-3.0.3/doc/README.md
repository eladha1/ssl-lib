OpenSSL Documentation
=====================

README.md  This file

[fingerprints.txt](fingerprints.txt)
        PGP fingerprints of authorised release signers

standards.txt
standards.txt
        Moved to the web, <https://www.openssl.org/docs/standards.html>

[HOWTO/](HOWTO/)
        A few how-to documents; not necessarily up-to-date

[man1/](man1/)
        The openssl command-line tools; start with openssl.pod

[man3/](man3/)
        The SSL library and the crypto library

[man5/](man5/)
        File formats

[man7/](man7/)
        Overviews; start with crypto.pod and ssl.pod, for example
        Algorithm specific EVP_PKEY documentation.

Formatted versions of the manpages (apps,ssl,crypto) can be found at
        <https://www.openssl.org/docs/manpages.html>
